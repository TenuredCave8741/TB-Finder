Please note that this program is for educational purposes only. 
The developers and contributors are not responsible for any misuse of this software.

T & B